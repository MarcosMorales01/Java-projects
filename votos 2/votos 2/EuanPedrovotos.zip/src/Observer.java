import java.util.ArrayList;


public interface Observer {
	public void actualizar(ArrayList<candidato> candidato);

}
