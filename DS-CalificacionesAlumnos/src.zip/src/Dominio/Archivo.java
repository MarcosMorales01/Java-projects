
package Dominio;

import com.opencsv.CSVWriter;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

/**
 *
 * @author Jose Marcos Morales Gomez
 */
public class Archivo {
    private ArrayList<String[]> informacion;
    private String ruta;
    
    public ArrayList<String[]> getInformacion() {
        return informacion;
    }

    public void setInformacion(ArrayList<String[]> informacion) {
        this.informacion = informacion;
    }
     
    
    public Archivo() {
        informacion = new ArrayList<>();
        ruta = "D:\\Equipo 2\\Morales\\Documents"
                 + "\\UADY\\4° Semestre\\Diseño de Software-Acomp\\alumnos.csv";
    }
    
    public void leerArchivo() throws IOException {
        BufferedReader br = null;
        
        try {
         
         br = new BufferedReader(new FileReader(ruta));
         String linea = br.readLine();
         String[] campos;
         
         while (null != linea) {
            campos = linea.split(",");
            informacion.add(campos);
            //System.out.println(Arrays.toString(campos));
            linea = br.readLine();
         }
            
            
            
         
      } catch (IOException e) {
         
      } finally {
         if (null != br) {
            br.close();
         }
      }
    }
    
    public void imprimirDatosDelArchivo() {
        Iterator<String[]> i = informacion.iterator();
        
        while(i.hasNext()){
            String[] elemento = i.next();
            System.out.print(Arrays.toString(elemento) +"\n");
        }
        
    }
    public void generarArchivo(ArrayList<String[]> calificaciones) throws IOException {
        
      CSVWriter escritor = new CSVWriter(new FileWriter("D:\\Equipo 2\\Morales\\Documents"
                 + "\\UADY\\4° Semestre\\Diseño de Software-Acomp\\calFinales.csv")); 
      
      for(int i = 0; i < informacion.size(); i++) {
          escritor.writeNext(informacion.get(i));
          escritor.writeNext(calificaciones.get(i));
      }
      escritor.close();
    }
}
