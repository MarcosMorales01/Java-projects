/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Javier
 */
public class Bolsa {
    
    private final static int PRECIO = 250;
    private final static int PESO = 2;
    
    public Bolsa(){
        
    }

    public static int getPRECIO() {
        return PRECIO;
    }

    public static int getPESO() {
        return PESO;
    }

    
}
