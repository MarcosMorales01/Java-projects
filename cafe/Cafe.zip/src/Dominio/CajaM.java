/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dominio;

/**
 *
 * @author Javier
 */
public class CajaM extends Caja {
    

    
    public CajaM (){
        
        this.capacidad=10;
        this.precio=5;
        this.tipo="Mediana";
        
    }
    
}
