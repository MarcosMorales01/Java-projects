# Contributing

For a quick introduction to the repository technologies, please read
[Hacking the library](https://github.com/popperjs/popper-core#hacking-the-library).

Full documentation is available
[on our official website](https://popper.js.org/docs/).

Before working on large code changes, please open an issue to discuss about it.
